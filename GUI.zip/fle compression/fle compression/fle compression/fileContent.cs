﻿namespace fle_compression
{
    internal class fileContent
    {
    }
}