﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace path_file
{
    public partial class Form1 : Form
    {
        List<string> listFiles = new List<string>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        

        private void ListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            




        }

        private void Button3_Click(object sender, EventArgs e)
        {
            {
                listFiles.Clear();
                listView1.Items.Clear();
                using (FolderBrowserDialog fbd = new FolderBrowserDialog())
                {
                    if (fbd.ShowDialog() == DialogResult.OK)
                    {
                        textBox1.Text = fbd.SelectedPath;
                        foreach (string item in Directory.GetFiles(fbd.SelectedPath))
                        {
                            listView1.images.Add(System.Drawing.Icon.ExtractAssociatedIcon(item));
                            FileInfo fi = new FileInfo(item);
                            listFiles.Add(fi.FullName);
                            listView1.Items.Add(fi.Name, listView1.Images.Count - 1);

                        }
                    }
                }
            }
        }
    }
}
